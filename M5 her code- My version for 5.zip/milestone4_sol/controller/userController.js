const createError = require("http-errors");
const express = require("express");

const Connection = require("../model/connection");
const ConnectionDB = require("../utility/connectionDB");

const User = require("../model/user");
const userDB = require("../utility/userDB");

const UserProfile = require("../model/user-profile");
const userProfileDB = require("../utility/userProfileDB");

const UserConnection = require("../model/user-connection");
const { check, validationResult } = require("express-validator");
var bodyParser = require("body-parser");
var urlencodedParser = bodyParser.urlencoded({ extended: false });
const router = express.Router();
router.use(express.json())
let error = new Array(1);

/* GET /cciconnect/login  */
router.post("/login",  urlencodedParser, [
  check("email",'Invalid Email Address').isEmail(),
  check("password", "Password must be 4 characters.").isString().isLength({min: 4}),
] ,  async function (req, res, next) {
  let email = req.body.email;
  let password = req.body.password;
  let username = req.body.email;
  let checkUser = await userDB.checkUser(username,password);
  
  const result = validationResult(req);
  var errors = result.errors;
  for (var key in errors) {
    console.log(errors[key].value);
}


  if (!result.isEmpty()){
    res.render('error', {
      errors: errors
    })
  }
 /* if (Object.keys(req.body).length != 0 ) {
    useDB.findOne({'email': req.body.email}), (err, user) => {
      if(!user) res.render('error').json({message: "Email or password Incorrect"});
    userDB.comparePassword(req.body.password, (err, isMatch) => {
      if(err) throw err;
      if(!isMatch) return res.render('error').json({message: "Invalid Password"})
    });
    res.render("savedConnections_1", {
      theUser: data.userProfile._user,
      userConnections: data.userProfile._userConnections,
    
    });
    */
   //Calling checkuser function if it is not in the database matching the email or password
   //redirects saying that login has failed
   //if it does exist it allows the user to login
   if (checkUser === null){
     
     //errors= "password or username is incorrect";
    return res.render('error1');
  }
  else{
   
 //if body is empty it wont execute
    if (Object.keys(req.body).length != 0 ) {
      console.log("User added");
    
    await intializeSessionVariable(req, res);
    let checkUser = await userDB.checkUser(email,password);
    //if(checkUser != 0){
     
    
    /*______________
    if (req.body.email && req.body.password != "") {
      let email = req.query.email;
      //action requested is search
      console.log("SEARCH POST");
      const userDB = new UserDB();
      user = await userDB.checkUser(email);
        console.log(user);
       
      
      console.log("user", user);
      req.theUser = {
        userProfile: req.session.userProfile,
      };
    }else {
  */
  
  let data = {
    userProfile: req.session.userProfile,
  };
  
  console.log("session initialized with user profile data ");
  console.log(data.userProfile._user);
  res.render("savedConnections_1", {
    theUser: data.userProfile._user,
    userConnections: data.userProfile._userConnections,
  
  });
}
};
});


 /* }
  else {
    res.render('error');
    throw new Error("Email or password Incorrect");
    
  }
});
_______________________
*/




/* mount middleware to check for session data */
router.use("/", function (req, res, next) {
  console.log("test cciconnect/myConnections ");
  //checking if session is already created
  if (!req.session.theUser) {
    //session doesn't exit route to login
    res.render("login");
  } else {
    // session exists go to next in the call stack
    next();
  }
});

/* GET /cciconnect/myconnections  */
router.get("/", function (req, res) {
  console.log("request to cciconnect/myConnections ");

  let data = {
    userProfile: req.session.userProfile,
  };
  res.render("savedConnections_1", {
    theUser: data.userProfile._user,
    userConnections: data.userProfile._userConnections,
  });
});

/* POST /cciconnect/myconnections/login  */
router.post("/login", function (req, res, next) {
  console.log("in login");

  intializeSessionVariable(req, res);

  let data = {
    userProfile: req.session.userProfile,
  };
  console.log("session initialized");
  console.log(data);
  res.render("savedConnections_1", {
    theUser: data.userProfile.user,
    userConnections: data.userProfile.userConnections,
  });
});
router.post("/signup", urlencodedParser, [
  check("userId").isString().isLength({min: 4}).withMessage("must be a string with 4 characters at least"),
  check("firstName").isLength({ min: 2 })
  .withMessage("must be 2 or more characters").isString(),
  check("lastName").isLength({ min: 2 })
  .withMessage("must be 2 or more characters").isString(),
  check("email").isEmail().withMessage("must be a valid email address"),
  check("state").isLength({ min: 2 })
  .withMessage("must be 2 or more characters").isString(),
  check("city").isLength({ min: 2 })
  .withMessage("must be 2 or more characters").isString(),
  check("zip").isLength({ min: 5 })
  .withMessage("Zip codes are 5 digits").isString(),
  check("country").isLength({ min: 2 })
  .withMessage("must be 2 or more characters").isString(),
  check("password")
  .isLength({ min: 4 })
      .withMessage("must be 4 or more characters")
      .matches(/^[a-z0-9 ]+$/i)
      .withMessage("may only contain letters numbers and spaces"),


],
async function  (req,res ,next )  {
  const errors = validationResult(req);
  if (!errors.isEmpty()){
   console.log(req.body.title);
   res.render('error', {error: errors.array() });
   return;
  }
  if (Object.keys(req.body).length != 0 ) {
    console.log("user has signed up");
    if (req.session.theUser) {
      const userId = req.body.userId;
      const firstName = req.body.firstName;
      const lastName = req.body.lastName;
      const email = req.body.email;
      const city = req.body.city;
      const state = req.body.state;
      const zip = req.body.zip;
      const password = req.body.password
      const country = req.body.country
      console.log(userId);
      console.log(firstName);
      console.log(lastName);
      console.log(email);
      console.log(city);
      console.log(state);
      console.log(zip);
      console.log(country);
      let userName =
        req.session.theUser.firstName + " " + req.session.theUser.lastName;
        let connectionDB = new ConnectionDB();
        let create = await connectionDB.createUser(
          userId,
          firstName,
          lastName,
          email,
          city,
          state,
          zip,
          country,
          userName

        );
        console.log("new user added")
        console.log(create);
        }
      }
    });
     

/* POST /cciconnect/myconnections  */
router.post("/rsvp", async function (req, res) {
  let code = req.body.connectionId;

  let rsvp = "";

  if (
    req.body.rsvp.toUpperCase() == "YES" ||
    req.body.rsvp.toUpperCase() == "NO" ||
    req.body.rsvp.toUpperCase() == "MAYBE"
  ) {
    rsvp = req.body.rsvp;
  }

  try {
    let userProfile = new UserProfile(
      req.session.userProfile._user,
      req.session.userProfile._userConnections
    );
    console.log("adding rsvp, profile before add");
    console.log(userProfile);
    let connectionDB = new ConnectionDB();
    let connection = await connectionDB.getConnection(code);
    userProfile.addConnection(connection, rsvp);
    console.log("adding rsvp, profile after add");
    console.log(userProfile);

    req.session.userProfile = userProfile;
    res.render("savedConnections_1", {
      theUser: req.session.userProfile._user,
      userConnections: req.session.userProfile._userConnections,
    });
  } catch (e) {
    console.log(e);
    error.push(404);
    res.redirect("/cciconnect/connections");
  }
});

/* POST /cciconnect/delete  */
router.post("/delete", async function (req, res, next) {
  let code = req.body.connectionId;
  if (req.session.theUser) {
    try {
      let userProfile = new UserProfile(
        req.session.userProfile._user,
        req.session.userProfile._userConnections
      );
      let connection = await new ConnectionDB().getConnection(code);
      userProfile.removeConnection(connection);
      req.session.userProfile = userProfile;
      res.render("savedConnections_1", {
        theUser: req.session.userProfile._user,
        userConnections: req.session.userProfile._userConnections,
      });
    } catch (e) {
      error.push(404);
      res.redirect("/cciconnect/connections");
    }
  } else {
    intializeSessionVariable(req, res);
  }
});

/* GET /cciconnect/signout  */
router.get("/signout", function (req, res, next) {
  req.session.destroy();
  res.render("index", { title: "Home", theUser: undefined });
});

/* GET /cciconnect/newConnection  */
router.get("/newConnection", function (req, res, next) {
  if (!req.session.theUser) {
    intializeSessionVariable(req, res);
  }
  res.render("newConnection", {
    title: "Home",
    theUser: req.session.userProfile._user,
  });
});

/* GET /cciconnect/myconnections/*  */
router.get("/*", function (req, res, next) {
  res.render("index", { title: "Home", theUser: req.session.theUser });
});






// initialzing session data
async function intializeSessionVariable(req, res) {
  //get username from request
  let username = req.body.email;
  let password = req.body.password;
 
  //only two users are currently saved. If neither use a default
  if (username != "norm@mail.com" && username != "noora@mail.com") {
    username = "norm@mail.com";
  }
  ///


  async function findUser(userName) {
    return new Promise(function(resolve, reject) {
      User.find({username: username}).exec(function(err, callback) {
      return resolve(callback);
      });
    });
  }





  ////
  //get user from database
  
  let user = await userDB.getUser(username);
  console.log("in User" ,user);
  let checkUser = await userDB.checkUser(username,password);
  console.log("in check user", checkUser);
  // get userprofile from databse
  userProfileConnections = await userProfileDB.selectUserConnections(
    user._email
  );

  // create UserProfile object
  let userProfile = new UserProfile();

  let userConnectionList = new Array();

  // create user connections for view (include connection details)
  if (userProfileConnections.length >= 1) {
    userConnectionList = await makeProfileConnectionsForView(
      userProfileConnections
    );
  }

  userProfile.setUser(user);
  userProfile.setUserConnections(userConnectionList);

  //creating session variable/property and storing a User in it
  req.session.theUser = user;

  // creating session variable/property and storing UserProfile object in it
  req.session.userProfile = userProfile;
  

}

async function makeProfileConnectionsForView(userConnections) {
  let userConnectionsArr = [];
  let theConnection;
  const connectionDB = new ConnectionDB();

  await asyncForEach(userConnections, async (element) => {
    try {
      theConnection = await connectionDB.getConnection(element.connection);
    } catch {
      console.log("error in fetching connection");
    }

    userConnection = new UserConnection(theConnection, element.rsvp);

    userConnectionsArr.push(userConnection);
  });
  return userConnectionsArr;
}

async function asyncForEach(array, callback) {
  for (let index = 0; index < array.length; index++) {
    await callback(array[index], index, array);
  }
}

module.exports = router;
 