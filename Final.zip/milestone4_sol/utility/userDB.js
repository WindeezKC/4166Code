const User = require("../model/user");

var mongoose = require("mongoose"),
  Schema = mongoose.Schema,
  ObjectId = Schema.ObjectId;

var userSchema = new mongoose.Schema({
  firstName: { type: String, default: "firstName" },
  lastName: { type: String, default: "lastName" },
  email: { type: String, default: "email" },
  password: { type: String, default: "pass" },
  userId: { type: String, default: "userId" },
  city: { type: String, default: "city" },
  state: { type: String, default: "state" },  
  zip: { type: String, default: "zip" },
  country: { type: String, default: "country" },

});
let dbModel = mongoose.model("User", userSchema, "Users");
userSchema.methods.comparePassword = function(enteredpassword, checkpassword){
  compare(enteredpassword, this.password, function(err,isMatch){
    if(err) return checkpassword(err)
    checkpassword(null, isMatch)
  })
}
module.exports.getUsers = function () {
  return new Promise((resolve, reject) => {
    dbModel
      .find()
      .then((data) => {
        //TO DO: make list of User objects
        resolve(data);
      })
      .catch((err) => {
        return reject(err);
      });
  });
}; //end findAll users

module.exports.getUser = function (userEmail) {
  return new Promise((resolve, reject) => {
    dbModel
      .findOne({
        email: userEmail,
      })
      .exec()
      .then((data) => {
        let user=[];
        //make user object and resolve
        let theUser = new User();
        theUser.setFirstName(data.firstName);
        theUser.setEmail(data.email);
        theUser.setPassword(data.password)
    
        
        resolve(theUser);
      })
      .catch((err) => {
        return reject(err);
      });
  });
}
module.exports.checkUser = function(userEmail,password) {
  return new Promise((resolve, reject) => {
    
    dbModel.findOne({
      $and : [
        {email: userEmail},{password: password}
      ]
    }
        ).exec(function(err, callback){
          console.log(callback);
          //if(callback ===null){
          //  throw new Error("Password or username is incorrect");
            
         // }
      return resolve(callback);
    
      
    });
  });
}
    
    
    
    
    
    /*  { email: userEmail},
      {password: password}
      ).exec()
      .then((data) => {
        let theUser = new User();
        theUser.setFirstName(data.firstName);
        theUser.setEmail(data.email);
        theUser.setPassword(data.password)
    
        
        resolve(theUser);
      })
    
    .catch((err) => {
      return reject(err);
    });
      */
      //(function(err, doc) { //email}).exec(function(err,doc) {
      //  console.log(doc);
      //return resolve(doc);
     
  //  });
  
  //}
    
/*module.exports.findUser = async function(username) {
  return new Promise(function(resolve, reject) {
    User.find({username: username}).exec(function(err, callback) {
    return resolve(callback);
    });
  });
}
*/


    /*.find({
      $and: [
        {email: email},
        {password: password},
      ],

    }) 
    
   .then((data)=>{
      let user =[];
      data.forEach((user)=> {
      let theUser = new User();
      theUser.setFirstName(data.firstName);
      theUser.setEmail(data.email);
      theUser.setPassword(data.password);
      theUser.push(user)
     
      });
    resolve(user);
  })
  .catch((err) => {
    return reject(err);
  });

});
}*/
////



//end find user
//module.exports.checkUser =  async function (email) {
  //const user =  await dbModel
   // .find({email: email}).exec(function(err, doc) {
       // return resolve(doc);
   // }),
 // }

  
 /* const user = await (await dbModel.findOne({email:email})).exec(function(err,doc){
    return resolve(doc);
  });
  if (user && password){
    return user
  }
};*/

  /*return new Promise((resolve, reject) => {
    dbModel.find({
      email: email, password: password.exec(function(err,doc) {
        return resolve(doc);
      })

    })
    .then((data) => {
      let users = [];
      data.forEach((user) => {
        let theUser = new User();
        theUser.setEmail(user.email);
        theUser.setPassword
      })
    })
  })
}*/

/*module.exports.checkUser = function(email, password){
  return new Promise((resolve, reject) =>{
    dbModel
      .find({
        $or:
        [{email: email}],
      })
      .then((data) => {
      let users= [];
        data.forEach((user) =>{
          let userObj = new User();
          
        })

      })
    }
  })
  */

module.exports.createUser= function(
  userId,
  firstName,
  lastName,
  email,
  city,
  state,
  zip,
  country,
  userName
) {
  return new Promise((resolve, reject)  => {
    dbModel
    .findOne({
      email: userEmail,
    })
    .exec(function ( err, user){
      let User = new dbModel({
              userId: user.userId +1,
              firstName: firstName,
              lastName: lastName,
              email: email,
              city: city,
              state: state,
              zip: zip,
              country: country,
      });
      User.save().then((data) => {
        let userObj = new User();
        userObj.setUserId(data.userId);
        userObj.setFirstName(data.firstName);
        userObj.setLastNamed(data.lastName);
        userObj.setEmail(data.email);
        userObj.setCity(data.city);
        userObj.setState(data.state);
        userObj.setZip(data.zip);
        userObj.setCountry(data.country);
        resolve(userObj);
      });
    });
  });
  }
  





